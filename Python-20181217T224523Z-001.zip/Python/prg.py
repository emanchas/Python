x = 5
y = 2
sum 5 + 2


print ('I love Apink')
